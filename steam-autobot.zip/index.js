const SteamUser = require('steam-user');
const SteamTotp = require('steam-totp');
const TradeOfferManager = require('steam-tradeoffer-manager');
const SteamCommunity = require('steamcommunity');

// 从 Railway 环境变量中读取账号信息和密钥
const username = process.env.STEAM_USERNAME;
const password = process.env.STEAM_PASSWORD;
const sharedSecret = process.env.SHARED_SECRET;
const identitySecret = process.env.IDENTITY_SECRET;

const client = new SteamUser();
const community = new SteamCommunity();
const manager = new TradeOfferManager({
  steam: client,
  domain: "example.com",
  language: "en"
});

client.logOn({
  accountName: username,
  password: password,
  twoFactorCode: SteamTotp.generateAuthCode(sharedSecret)
});

client.on('loggedOn', () => {
  console.log('✅ 登录成功');
  client.setPersona(SteamUser.EPersonaState.Online);
});

client.on('webSession', (sessionID, cookies) => {
  manager.setCookies(cookies);
  community.setCookies(cookies);
  community.startConfirmationChecker(30000, identitySecret);
  console.log('🔐 Web session 设置完成，开始监听报价...');
});

manager.on('newOffer', offer => {
  console.log(`📩 收到报价来自 ${offer.partner.getSteamID64()}`);

  if (offer.itemsToGive.length === 0) {
    offer.accept(err => {
      if (err) {
        console.log('❌ 接受报价失败:', err);
      } else {
        console.log('✅ 自动接受报价成功');
      }
    });
  } else {
    offer.decline();
    console.log('⚠️ 报价被拒绝（不是纯赠送）');
  }
});

setInterval(() => {
  console.log('📡 Bot 仍在运行中...');
}, 60000);